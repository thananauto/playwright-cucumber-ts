import pandas as pd
import json
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, filename='etl_log.log', filemode='w',
                    format='%(asctime)s - %(levelname)s - %(message)s')

# Load configuration from a JSON file
def load_config(config_file):
    with open(config_file, 'r') as file:
        return json.load(file)
    
 # Categorize by region based on country
def add_region(country):
    regions = {
        'North America': ['USA', 'Canada', 'Mexico', 'Alaska'],
        'Europe': ['UK', 'Germany', 'France', 'Italy', 'Spain', 'Poland', 'Greece'],
        'Asia': ['India', 'China', 'Japan', 'Singapore', 'Dubai']
    }
    for region, countries in regions.items():
        if country.lower() in [x.lower() for x in countries]:
            return region
    return 'Other'

def filter_age_above_18(data):
     # check all age column values with numbers
    data = data[data['age'].astype(str).str.match(r'^\d+(\.\d+)?$')]
    logging.info(f"Filter the age column have numeric. Rows remaining: {len(data)}")

    # filter age above 18
    data = data[data['age'].astype(int) < 18 ] 
    data = data[data['age'].astype(int) > 0]
    data['age'] = data['age'].astype(int)
    logging.info(f"Filtered age under 18. Rows remaining: {len(data)}")
    return data


# processing of input file
def etl_runner(config):
    try:
        # Data Extraction
        input_file = config['input_file']
        data = pd.read_csv(input_file)
        logging.info(f"Data extracted successfully from {input_file}. Rows: {len(data)}")

        # Data Transformation
        # Remove rows with missing or invalid data
        data = data.dropna()
        logging.info(f"Removed rows with missing data. Rows remaining: {len(data)}")

       
        data = filter_age_above_18(data)
        # Normalize text fields
        data['name'] = data['name'].str.title()
        data['email'] = data['email'].str.lower()

        # Filter customers under age 18
      

       # Filter the invalid email address
        data = data[data['email'].str.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')]
        logging.info(f"Filtered valid email address. Rows remaining: {len(data)}")

        # add the new column region
        data['region'] = data['country'].apply(add_region)

        # Data Loading
        output_file = config['output_file']
        data.to_csv(output_file, index=False)
        logging.info(f"Data loaded successfully into {output_file}. Rows processed: {len(data)}")
    except Exception as e:
        logging.error(f"Error during ETL process: {e}")
        raise

if __name__ == "__main__":
    config = load_config('config.json')
    etl_runner(config)
