# ETL Script for Data Processing

This script performs data extraction, transformation, and loading (ETL) tasks for customer data in a CSV file. It includes cleaning, normalizing, and categorizing data while ensuring robust error handling and logging.

## Features
- Extract data from a CSV file.
- Clean and transform data:
  - Remove rows with missing or invalid values.
  - Normalize text fields (e.g., title case for names).
  - Filter customers under age 18.
  - Validate email addresses.
  - Categorize customers by region based on their country.
- Load transformed data into a new CSV file.
- Comprehensive logging for processing and errors.

## Requirements
- Python 3.x
- Pandas
- Logging library

## Configuration
Configuration is managed using a JSON file, which specifies the input and output file paths.


### Example `config.json`
```json
{
  "input_file": "input.csv",
  "output_file": "output.csv"
}
```
## Setup
* Create the virtual environment
`python3 -m venv venv`

* Activate the virtual environment
    - For WINDOWS

        `venv\Scripts\activate.bat`

    - For MAC

        `venv\Scripts\activate`

* Install the dependencies file
    `pip install -r requirements.txt`

* Run the test file
    `python3 test.py`

Once the test execution completed you can find the result in `output.csv`




